import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:hello_me/auth_repository.dart';
import 'package:firebase_auth/firebase_auth.dart';




class SignUpButton extends StatelessWidget {
  final userEmailController;
  final userPasswordController;

  const SignUpButton(
      {Key? key, required this.userEmailController, required this.userPasswordController})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthRepository>(
      builder: (context, authRep, child) {
        return ElevatedButton(
          onPressed: () async {
            UserCredential? newUser = await authRep.signUp(
                userEmailController.text.trim(),
                userPasswordController.text.trim());
            if (newUser == null) {
              ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('There was an error signing up to the app'),
                  )
              );
            }
            else {
              ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('You were signed up successfully'),
                  )
              );
              Navigator.of(context).popUntil((route) => route.isFirst);
            }
          },
          style: ElevatedButton.styleFrom(
            minimumSize: const Size.fromHeight(30),
            primary: authRep.status == Status.Authenticating
                ? Colors.grey
                : Colors.deepPurple,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(50),
            ),
          ),
          child: const Text("Sign Up"),
        ); // ElevatedButton
      },
    ); // Consumer
  }
}
